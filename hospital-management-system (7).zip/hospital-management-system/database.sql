-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: hospital_management
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP database if exists hospital_management;
create database hospital_management;
use hospital_management;


--
-- Table structure for table `doctordetails`
--

DROP TABLE IF EXISTS `doctordetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctordetails` (
  `doctor_id` int NOT NULL AUTO_INCREMENT,
  `doctor_name` varchar(255) DEFAULT NULL,
  `doctor_specialization` varchar(255) DEFAULT NULL,
  `experience` double DEFAULT NULL,
  `doctor_status` enum('AVAILABLE','UNAVAILABLE') DEFAULT NULL,
  `employe_id` varchar(255) DEFAULT NULL,
  `doctor_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctordetails`
--

LOCK TABLES `doctordetails` WRITE;
/*!40000 ALTER TABLE `doctordetails` DISABLE KEYS */;
INSERT INTO `doctordetails` VALUES (1,'Dr Sachin Pandey','Physicians and surgeons',5,'AVAILABLE','D001','sachin@gmail.com'),(2,'Dr Kishore','Cardiologist',8,'AVAILABLE','D002','kishor@gmail.com'),(3,'Dr Likhita','Dentist',10,'UNAVAILABLE','D003','likhitha@gmail.com'),(4,'Dr Bhagyashree','Oncologist',11,'UNAVAILABLE','D004','bhagya@gmail.com'),(5,'Dr Sahithi','Dermatologist',14,'AVAILABLE','D005','sahithi@gmail.com'),(6,'Dr Prasanna','Neurologist',30,'AVAILABLE','D006','prasanna@gmail.com'),(7,'Dr Raghavendra','Neurosurgeon',10,'AVAILABLE','D007','raghav@gmail.com'),(8,'Dr Swathi','Gynecologist',15,'AVAILABLE','D008','swathi@gmail.com'),(9,'Dr Harshit','Veterinarian',1,'AVAILABLE','D009','harshit@gmail.com'),(10,'Dr Javed','Pulmonologist',5,'AVAILABLE','D010','javed@gmail.com'),(13,'Dr Sachin','Pediatrician',10,'AVAILABLE','D011','sachin@gmail.com'),(14,'Dr Aditya','Dermatologist',10,'AVAILABLE','D012','aditya@gmail.com');
/*!40000 ALTER TABLE `doctordetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `issue_id` int NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) NOT NULL,
  `treatment_cost` double DEFAULT NULL,
  PRIMARY KEY (`issue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,'Fever',100),(2,'Headache',100),(3,'Cold Flu',200),(4,'Diarrhea',300),(5,'Stomach-Ache',100),(6,'Cancer',500000),(7,'Heart-Attack',50000),(8,'HIV',100000),(9,'Kidney-Failure',5000),(10,'Diabetes',10000),(11,'Strokes',30000),(12,'Fever',500);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_history`
--

DROP TABLE IF EXISTS `medical_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_history` (
  `med_his_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `treatment_day` int DEFAULT NULL,
  `treatment_description` text,
  PRIMARY KEY (`med_his_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `medical_history_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patientdetails` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_history`
--

LOCK TABLES `medical_history` WRITE;
/*!40000 ALTER TABLE `medical_history` DISABLE KEYS */;
INSERT INTO `medical_history` VALUES (1,1,1,'Paracetamol'),(2,1,2,'Gave Dolo');
/*!40000 ALTER TABLE `medical_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientdetails`
--

DROP TABLE IF EXISTS `patientdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientdetails` (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(255) DEFAULT NULL,
  `patient_phone` varchar(255) DEFAULT NULL,
  `patient_state` varchar(255) DEFAULT NULL,
  `patient_email` varchar(255) DEFAULT NULL,
  `patient_aadhaar` varchar(255) DEFAULT NULL,
  `patient_pincode` varchar(255) DEFAULT NULL,
  `patient_city` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientdetails`
--

LOCK TABLES `patientdetails` WRITE;
/*!40000 ALTER TABLE `patientdetails` DISABLE KEYS */;
INSERT INTO `patientdetails` VALUES (1,'Sachin ','7518693356','UP','sachin@pandey.atd','478935437897','272193','Siddharth Nagar'),(2,'Raghav Tripathi','7623763742','Uttar Pradesh','raghav@gmail.com','478935437897','226028','Lucknow'),(3,'Ramendra Verma','7832782342','Uttar Pradesh','ramu@ramendra.verma','478935437897','226028','Lucknow'),(4,'Sachin Pandey','7623763742','Uttar Pradesh','sachin@gmail.com','478935437897','226028','Lucknow'),(5,'Raghav Tripathi','7623763742','Uttar Pradesh','raghav@gmail.com','478935437897','226028','Lucknow'),(6,'Utkarsh Pandey','7623763742','Uttar Pradesh','utkarsh@gmail.com','478935437897','226028','Lucknow'),(7,'Shivam Tripathi','7437843674','Uttar Pradesh','shivam@tripathi.com','478935437897','226028','Lucknow'),(8,'Shalini Agrahari','7623763742','Uttar Pradesh','shalini@gmail.com','478935437897','226028','Lucknow'),(9,'Raghav Tripathi','7623763742','Uttar Pradesh','raghav@gmail.com','478935437897','226028','Lucknow'),(10,'KishoreSwamy','7623763742','Uttar Pradesh','pandey@gmail.com','478935437897','226028','Lucknow'),(11,'Sachin Pandey','7518693356','Uttar Pradesh','sachin@pandey.atd','478935437897','226028','Lucknow'),(12,'Sachin Pandey','7518693356','Uttar Pradesh','sachin@pandey.atd','478935437897','226028','Lucknow'),(13,'Sachin Pandey','7518693356','Uttar Pradesh','sachin@pandey.atd','478935437897','226028','Lucknow');
/*!40000 ALTER TABLE `patientdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentdetails`
--

DROP TABLE IF EXISTS `paymentdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paymentdetails` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `amount` double DEFAULT NULL,
  `due_amount` double DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `paymode` varchar(255) DEFAULT NULL,
  `treatment_id` int NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `treatment_id_idx` (`treatment_id`),
  KEY `treatment_id_key` (`treatment_id`),
  CONSTRAINT `treatment_id` FOREIGN KEY (`treatment_id`) REFERENCES `treatmentdetails` (`treatment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentdetails`
--

LOCK TABLES `paymentdetails` WRITE;
/*!40000 ALTER TABLE `paymentdetails` DISABLE KEYS */;
INSERT INTO `paymentdetails` VALUES (1,100,0,'2022-12-16','UPI',1),(2,400,0,'2022-12-16','UPI',2),(3,200,0,'2022-12-16','UPI',3),(4,50,50,'2022-12-26','UPI',7),(5,500000,500,'2022-12-26','UPI',9),(6,100,499900,'2022-12-29','Credit Card',11),(7,50000,449900,'2022-12-29','CASH',11),(8,50000,399900,'2022-12-29','Net Banking',11),(9,500,0,'2022-12-29','UPI',9),(10,100,2000,'2022-12-29','UPI',10),(11,1000,1000,'2022-12-29','Credit Card',10),(12,1234,29366,'2023-01-02','PayTM Wallet',13),(13,99900,300000,'2023-01-02','Credit Card',11);
/*!40000 ALTER TABLE `paymentdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_limit`
--

DROP TABLE IF EXISTS `room_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_limit` (
  `room__limit` int NOT NULL,
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_limit`
--

LOCK TABLES `room_limit` WRITE;
/*!40000 ALTER TABLE `room_limit` DISABLE KEYS */;
INSERT INTO `room_limit` VALUES (20,1);
/*!40000 ALTER TABLE `room_limit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `room_id` int NOT NULL AUTO_INCREMENT,
  `room_cost` double NOT NULL,
  `status` enum('AVAILABLE','UNAVAILABLE') DEFAULT 'AVAILABLE',
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,500,'AVAILABLE'),(2,100,'AVAILABLE'),(3,100,'AVAILABLE'),(4,500,'AVAILABLE'),(5,500,'AVAILABLE'),(6,500,'AVAILABLE'),(7,500,'AVAILABLE'),(8,500,'AVAILABLE'),(9,1000,'AVAILABLE'),(10,400,'UNAVAILABLE'),(11,300,'AVAILABLE'),(12,600,'AVAILABLE'),(13,800,'AVAILABLE'),(14,550,'AVAILABLE'),(15,800,'AVAILABLE'),(16,1000,'AVAILABLE');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatmentdetails`
--

DROP TABLE IF EXISTS `treatmentdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatmentdetails` (
  `treatment_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `visitingOrAdmitting` tinyint DEFAULT NULL,
  `treatment_date` date DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `room_id` int DEFAULT NULL,
  `issue_id` int NOT NULL,
  PRIMARY KEY (`treatment_id`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `room_id_idx` (`room_id`),
  KEY `issue_id_idx` (`issue_id`),
  CONSTRAINT `issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`),
  CONSTRAINT `treatmentdetails_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patientdetails` (`patient_id`),
  CONSTRAINT `treatmentdetails_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctordetails` (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatmentdetails`
--

LOCK TABLES `treatmentdetails` WRITE;
/*!40000 ALTER TABLE `treatmentdetails` DISABLE KEYS */;
INSERT INTO `treatmentdetails` VALUES (1,1,10,0,'2022-12-16',NULL,0,1),(2,2,9,1,'2022-12-16','2022-12-16',1,4),(3,3,1,1,'2022-12-16','2022-12-16',2,5),(4,4,1,0,'2022-12-23',NULL,0,1),(5,5,2,1,'2022-12-23','2022-12-23',3,8),(6,6,3,1,'2022-12-23',NULL,10,8),(7,7,1,0,'2022-12-26',NULL,0,2),(9,8,1,1,'2022-12-26','2022-12-26',6,6),(10,9,2,1,'2022-12-26','2022-12-29',7,5),(11,9,1,0,'2022-12-29',NULL,0,6),(12,10,9,0,'2023-01-02',NULL,0,8),(13,10,5,1,'2023-01-02','2023-01-02',12,11),(14,4,1,0,'2023-01-02',NULL,0,3);
/*!40000 ALTER TABLE `treatmentdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `security_num` int DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'sachinpandeyatd1','4caff60dd85d0995cd5a9390ce7b6a78',1,123456),(2,'spatd123','e8e75b3f3b9edf651d400178ab75cf2e',1,543677),(3,'spatd1234','a219c6213dc4cec3646575e778bc0625',1,214354),(5,'spatd12345','e8e75b3f3b9edf651d400178ab75cf2e',1,343254),(13,'spatd121','e8e75b3f3b9edf651d400178ab75cf2e',1,673673),(14,'spatd122','e8e75b3f3b9edf651d400178ab75cf2e',0,847376),(16,'spatd124','e8e75b3f3b9edf651d400178ab75cf2e',1,673246),(17,'spatd125','e8e75b3f3b9edf651d400178ab75cf2e',1,673267);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-03 12:22:58
