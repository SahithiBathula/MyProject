package com.infinite.hospital_management_system;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;


@ManagedBean
@SessionScoped
public class HospitalDao {
	SessionFactory sessionFactory;
	PreparedStatement preparedStatement;
	Connection connection;
	
	
	//searching users to check if he/she already exists for signup
	public List<Users> searchUser(String username){
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(Users.class);
        criteria.add(Restrictions.eq("username", username));
        List<Users> userlist = criteria.list();
        return userlist;
    }
    
    public boolean validateUser(String userName) {
		List<Users> userlist = searchUser(userName);
		if(userlist.size() > 0) {
		    return true;
		}
		else {
		    return false;
		}
    }
    
    public String hashPasswordWithMD5(String plainPassword) throws NoSuchAlgorithmException {
    	MessageDigest messageDigest5 = MessageDigest.getInstance("MD5");
    	
    	messageDigest5.update(plainPassword.getBytes());
    	byte[] hashBytes = messageDigest5.digest();
    	
    	StringBuilder hashString = new StringBuilder();
    	
    	for(int i = 0; i < hashBytes.length; i++){
    		hashString.append(Integer.toString((hashBytes[i] & 0xff) + 0x100, 16).substring(1));
    	}
    	
    	return hashString.toString();
	}
	
	public String signup(Users users) throws NoSuchAlgorithmException {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		boolean isUsernameExists = validateUser(users.getUsername());
		FacesContext context = FacesContext.getCurrentInstance();
		
        if(isUsernameExists == true) {
             context.addMessage("form:username", new FacesMessage("Username already Exists, try some other username"));
             return null;
        }
        else {
        	users.setPassword(hashPasswordWithMD5(users.getPassword()));
        	users.setStatus(0);
        	
	        Transaction transaction = session.beginTransaction();
	        session.save(users);
	        transaction.commit();
	        session.close();
			
			return "user-login.xhtml?faces-redirect=true";
        }
	}
	
	//login
	public void login(String username, String password) throws IOException, NoSuchAlgorithmException {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		String hashedPassword = hashPasswordWithMD5(password);
		
		Query query = session.createQuery("SELECT count(*) FROM Users WHERE username = :username AND password = :password AND status=1");
		query.setParameter("username", username);
		query.setParameter("password", hashedPassword);
		Long count = (Long) query.list().get(0);
		
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = context.getExternalContext();
		
		if (count == 0) {
            context.addMessage("form:password", new FacesMessage("Credentials did not match, please enter correct credentials and try again"));
        } 
		
		if(count == 1){
            externalContext.getSessionMap().put("username", username);
            externalContext.redirect("index.jsp");
        }
	}
	
	//New Admin signup List (to approve or deny by existing admin)
	@SuppressWarnings("unchecked")
	public List<String> approveOrDenyNewAdmin() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		return (List<String>) session.createQuery("from Users where status=0").list();
	}
	
	//Approve or deny here
	public void approveOrDenyNewSignups(String username, String action) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		Users users = searchUser(username).get(0);
		
		if (action.equals("approve")) {
			users.setStatus(1);
			session.update(users);
			session.beginTransaction().commit();
			session.close();
		}
		
		if (action.equals("deny")) {
			session.delete(users);
			session.beginTransaction().commit();
			session.close();
		}
	}
	
	//LOGOUT Method
	public String logout() throws IOException {
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = context.getExternalContext();
		externalContext.getSessionMap().remove("username");
		externalContext.redirect("user-login.xhtml");
		
		return null;
	}
	
	//User List
	public Users userList(String username){
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession(); 
        Criteria criteria = session.createCriteria(Users.class);
        criteria.add(Restrictions.eq("username", username));
        List<Users> userlist = criteria.list();
        return userlist.get(0);
    }
	
	//forget password
	public String forgotPassword(Users users) throws NoSuchAlgorithmException {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        FacesContext context = FacesContext.getCurrentInstance();
        
        Users user  = userList(users.getUsername());

        if(user.getSecurityNum() == users.getSecurityNum() && user.getUsername().equals(users.getUsername())) {
        	user.setPassword(hashPasswordWithMD5(users.getPassword()));
	        Transaction transaction = session.beginTransaction();
	        
	        session.update(user);
	        transaction.commit();
	        session.close();
	        return "User Password Updated";
        }
        else {
           context.addMessage("form:username", new FacesMessage("Invalid "));
           return null;
        }
    }
	
	 public List<Patient> searchAadhaar(String patientAadhaar){
	        sessionFactory = SessionHelper.getConnection();
	        Session session = sessionFactory.openSession();
	        Criteria criteria = session.createCriteria(Patient.class);
	        criteria.add(Restrictions.eq("patientAadhaar", patientAadhaar));
	        List<Patient> aadhaarlist = criteria.list();
	        return aadhaarlist;
	    }

	    public boolean validateAadhaar(String patientAadhaar) {
	        List<Patient> aadhaarlist = searchAadhaar(patientAadhaar);
	        if(aadhaarlist.size() > 0 ) {
	            return true;
	        }else {
	            return false;
	        }
	    }

	    //AddPatient
	    public String addPatient(Patient patient) {
	        sessionFactory = SessionHelper.getConnection();
	        Session session = sessionFactory.openSession();

	        boolean aadhaar = validateAadhaar(patient.getPatientAadhaar());
	        FacesContext context = FacesContext.getCurrentInstance();

	        if(aadhaar == true) {
	             context.addMessage("form:patientAadhaar", new FacesMessage("Aadhaar Number already Exists, try some other Aadhaar Number"));
	             return null;
	        }
	        else {
	        Transaction transaction = session.beginTransaction();
	        session.save(patient);
	        transaction.commit();
	        session.close();
	        return "show-patient.xhtml?faces-redirect=true";
	        }
	    }

	//ShowPatient
	public List<Patient> showPatient(){
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Query query =  session.createQuery("from Patient");
		List<Patient> patientlist = query.list();
		return patientlist;
	}
	
	//SearchPatient
	public List<Patient> searchPatient(int patientId) {		
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Patient.class);
		criteria.add(Restrictions.eq("patientId", patientId));
		List<Patient> patientlist = criteria.list();
		return patientlist;
	}
	
	//Update Patient 
    public String updatePatient(Patient patient) {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.update(patient);
        transaction.commit();
        session.close();
        return "Patient Detals Updated Successfully.";
    }
	
	//Patient details
	public List<String> patientDetails() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		List<String> patientDetailList = new ArrayList<String>();
		
		//Total number of patients
		patientDetailList.add(String.valueOf(showPatient().size()));
		
		//Total admitted patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where visitingOrAdmitting = 1").list().get(0) + "");
		
		//Total visiting patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where visitingOrAdmitting = 0").list().get(0) + "");
		
		//Total discharged patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where dischargedate is not null").list().get(0) + "");
		
		//Not discharged patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where visitingOrAdmitting = 1 and dischargedate is null").list().get(0) + "");
		
		//Today's patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where treatmentdate = '" + currentDate() + "'").list().get(0) + "");
		
		//Today's admiting patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where visitingOrAdmitting = 1 and treatmentdate = '" + currentDate() + "'").list().get(0) + "");		
		
		//Today's visiting patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where visitingOrAdmitting = 0 and treatmentdate = '" + currentDate() + "'").list().get(0) + "");		
		
		//Today's discharged patients
		patientDetailList.add(session.createQuery("SELECT count(*) from Treatment where dischargedate is not null and treatmentdate = '" + currentDate() + "'").list().get(0) + "");
		
		return patientDetailList;
	}
	
	//ShowMedHistory
    public List<MedicalHistory> showMedicalHistory(){
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Query query =  session.createQuery("from MedicalHistory");
        List<MedicalHistory> medicalHistorylist = query.list();
        return medicalHistorylist;
    }
    
    public boolean ifPatientExists(int patientId) {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        boolean ifPatientExists = false;
        
        long patientCount = (long) session.createQuery("SELECT count(*) from Patient where patientId = " + patientId).list().get(0);
        
        if(patientCount == 0){
        	ifPatientExists = true;
        }
        
        return ifPatientExists;
	}
    
    //AddMedicalHistory
    public String addMedicalHistory(MedicalHistory medicalHistory) {
    	if (ifPatientExists(medicalHistory.getPatientId()) == true) {
    		FacesContext context = FacesContext.getCurrentInstance();
    		
    		context.addMessage("form:patientId", new FacesMessage("Patient ID doesn't exist"));
    		
    		return null;
    	}
    	
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        Transaction transaction = session.beginTransaction();
        session.save(medicalHistory);
        transaction.commit();
        session.close();
        
        return "show-medical-history.xhtml?faces-redirect=true";
    }

    //searchMedicalHistory 
    @SuppressWarnings("unchecked")
	public List<MedicalHistory> searchMedicalHistory(int patientId) {
        return SessionHelper.getConnection().openSession().createQuery("from MedicalHistory where patientId = " + patientId).list();
    }
    
  //SearchPayments
  	public List<Payment> searchPayment(int paymentId) {
  		sessionFactory = SessionHelper.getConnection();
  		Session session = sessionFactory.openSession();
  		Criteria criteria = session.createCriteria(Payment.class);
  		criteria.add(Restrictions.eq("paymentId", paymentId));
  		List<Payment> paymentlist = criteria.list();
  		return paymentlist;
  	}
  	
  	//Number of dates between admitting date and discharge date
  	public int noOfDays(Date admittingDate, Date dischargeDate) {
		int totalDays= dischargeDate.getDate() - admittingDate.getDate();
		return ++totalDays;
	}
  	
  	//search payment by treatment id
  	public double searchPaymentByTreatmentID(int treatmentId) {
  		double amount = 0;
  		sessionFactory = SessionHelper.getConnection();
  		Session session = sessionFactory.openSession();
  		
  		Long count = (Long) session.createQuery("SELECT count(*) from Payment where treatment_id = " + treatmentId).list().get(0);
  		
  		if(count > 0){
  			amount = (double) session.createSQLQuery("SELECT sum(amount) from paymentdetails where treatment_id = " + treatmentId).list().get(0);
  		}
		return amount;
	}
  	
  	//Total due amount
  	public double dueAmount(int treatmentId) {
  		Treatment treatment = searchTreatment(treatmentId).get(0);
  		
  		double roomCost = 0;
  		if (treatment.getRoomId() > 0) {
  			Room room = searchRoomById(treatment.getRoomId());
  			int noOfDays = noOfDays(treatment.getTreatmentdate(), treatment.getDischargedate());
			roomCost = room.getRoomCost() * noOfDays;
		}
  		
  		Issues issues = searchIssue(treatment.getIssueId()).get(0);
  		
  		
  		double amount = searchPaymentByTreatmentID(treatmentId);
  		
  
  		return (roomCost + issues.getTreatmentCost()) - amount;
	}
  	
  	
  	//AddPayment
	public void addPayment(Payment payment) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		java.util.Date date = new java.util.Date();
		Date paymentdate = new Date(date.getTime());
		payment.setPaymentDate(paymentdate);
		payment.setDueAmount(payment.getDueAmount() - payment.getAmount());
		
		Transaction transaction = session.beginTransaction();
		session.save(payment);
		transaction.commit();
		session.close();
	}
	
	//ShowPayments
	@SuppressWarnings("unchecked")
	public List<Payment> showPayments(){
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Query query =  session.createQuery("from Payment");
		List<Payment> paymentlist = query.list();
		return paymentlist;
	}
	
	//Payment Details
	public List<String> paymentDetails() {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		List<String> paymentDetails = new ArrayList<String>();
		
		//Total payments
		paymentDetails.add(showPayments().size() + "");
		
		//Total paid amount
		paymentDetails.add(session.createQuery("SELECT sum(amount) from Payment").list().get(0) + "");
		
		//Total due amount
		String dueAmountQuery = "SELECT SUM(due_amount) FROM paymentdetails WHERE payment_id IN (SELECT MAX(payment_id) FROM paymentdetails GROUP BY treatment_id)";
		paymentDetails.add(session.createSQLQuery(dueAmountQuery).list().get(0) + "");
		
		//Today's payments
		paymentDetails.add(session.createQuery("SELECT count(*) from Payment where paymentDate = '" + currentDate() + "'").list().get(0) + "");
		
		//Today's paid amount
		paymentDetails.add(session.createQuery("SELECT sum(amount) from Payment where paymentDate = '" + currentDate() + "'").list().get(0) + "");
		
		//Today's due amount
		String todaysDueAmountQuery = "SELECT SUM(due_amount) FROM paymentdetails WHERE payment_date = '" + currentDate() + "' AND payment_id IN (SELECT MAX(payment_id) FROM paymentdetails GROUP BY treatment_id)";
		paymentDetails.add(session.createSQLQuery(todaysDueAmountQuery).list().get(0) + "");
		
		return paymentDetails;
	}
    
	
	//Admission of patient
	public String admitPatient(Admission admission) {
		Session session = SessionHelper.getConnection().openSession();
		
		session.save(admission);
		session.beginTransaction().commit();
		
		return "Patient Admited.";
	}
	
	
	public Date convertDate(java.util.Date dt) {
        java.sql.Date sqlDate=new java.sql.Date(dt.getTime());
        return sqlDate;
    }
	
	//Available rooms
	@SuppressWarnings("unchecked")
	public List<Integer> showAvailableRooms() {
		return (List<Integer>) SessionHelper.getConnection().openSession().createQuery("SELECT roomId from Room where status = 'AVAILABLE' ").list();
	}
	
	public Room searchRoomById(int roomId) {
		return (Room) SessionHelper.getConnection().openSession().createQuery("from Room where roomId = " + roomId).list().get(0);
	}
	
	public Doctor searchDoctorById(int doctorId) {
		return (Doctor) SessionHelper.getConnection().openSession().createQuery("from Doctor where doctorId =" + doctorId).list().get(0);
	}
    
	@SuppressWarnings("unchecked")
	public List<Doctor> showAllAvailableDoctors() {
		return (List<Doctor>) SessionHelper.getConnection().openSession().createQuery("from Doctor where doctorStatus = 'AVAILABLE'").list();
	}
	
	public List<Issues> showAllIssues() {
		return (List<Issues>) SessionHelper.getConnection().openSession().createQuery("from Issues").list();
	}
	
	//current date
	public java.sql.Date currentDate() {
		return new java.sql.Date(new java.util.Date().getTime());
	}
	
	//AddTreatment  
    public void addTreatment(Treatment treatment) {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();  
        
        treatment.setTreatmentdate(currentDate());
        
        session.save(treatment);
        session.beginTransaction().commit();
        session.close();
        
        if(treatment.getRoomId() > 0){
	        session = sessionFactory.openSession();
	        Room room = searchRoomById(treatment.getRoomId());
	        room.setStatus("UNAVAILABLE");
	        session.update(room);
	        session.beginTransaction().commit();
	        session.close();
        }
        
        if (treatment.getVisitingOrAdmitting() == 1) {
        	Doctor doctor = searchDoctorById(treatment.getDoctorid());
        	doctor.setDoctorStatus("UNAVAILABLE");
        	
        	session = sessionFactory.openSession();
        	session.update(doctor);
        	session.beginTransaction().commit();
        	session.close();  	
		}
        
    }
    
    //ShowTreatment
    @SuppressWarnings("unchecked")
	public List<Treatment> showTreatment(){
        return (List<Treatment>) SessionHelper.getConnection().openSession().createQuery("from Treatment").list();
    }
    
    //SearchTreatment
    public List<Treatment> searchTreatment(int treatmentId) {
	    return (List<Treatment>) SessionHelper.getConnection().openSession().createCriteria(Treatment.class).add(Restrictions.eq("treatmentId", treatmentId)).list();
    }
    
    //Treatment Details
    public List<String> treatmentDetails() {
    	sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		List<String> treatmentDetails = new ArrayList<String>();
    	
		//Total treatments
		treatmentDetails.add(showTreatment().size() + "");
		
		//Today's treatment
		treatmentDetails.add(session.createQuery("SELECT count(*) from Treatment where treatmentdate = '" + currentDate() + "'").list().get(0) + "");
		
    	return treatmentDetails;
	}
    
    //Discharge
    public void discharge(int treatmentId) {
    	Session session = SessionHelper.getConnection().openSession();
    	
        Treatment treatment = searchTreatment(treatmentId).get(0);
        treatment.setDischargedate(new java.sql.Date(new java.util.Date().getTime()));
        session.update(treatment);
        session.beginTransaction().commit();
        session.close();
        
        Doctor doctor = searchDoctorById(treatment.getDoctorid());
        doctor.setDoctorStatus("AVAILABLE");
        
        session = SessionHelper.getConnection().openSession();
        session.update(doctor);
        session.beginTransaction().commit();
        session.close();  
        
        Room room = searchRoomById(treatment.getRoomId());
        room.setStatus("AVAILABLE");
        
        session = SessionHelper.getConnection().openSession();
        session.update(room);
        session.beginTransaction().commit();
        session.close();
	}
    
    //search issue
    public List<Issues> searchIssue(int issueId) {
		return (List<Issues>) SessionHelper.getConnection().openSession().createQuery("from Issues where issueId = " + issueId).list();
	}
    
    
    //show Doctor 
    public List<Doctor> showAllDoctors() {
		return SessionHelper.getConnection().openSession().createQuery("from Doctor").list();
	}
	
  //GenerateEmployId
    public String GenerateEmployId() {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Criteria cr = session.createCriteria(Doctor.class);
        List<Doctor> doctorlist = cr.list();
        session.close();
        if (doctorlist.size() == 0) {
            return "D001";
        } else {
            String id = doctorlist.get(doctorlist.size() - 1).getEmployeId();
            int id1 = Integer.parseInt(id.substring(1));
            id1++;
            String id2 = String.format("D%03d", id1);
            return id2;
        }
    }

    //Add Doctor
    public String addDoctor(Doctor doctor) {
        Session session = SessionHelper.getConnection().openSession();
        String empid = GenerateEmployId();
        doctor.setEmployeId(empid);
        doctor.setDoctorStatus("AVAILABLE");
        session.save(doctor);
        session.beginTransaction().commit();
        session.close();

        return "show-doctors.xhtml?faces-redirect=true";
    }
	
	
	//Doctor Details for home page
	public List<String> doctorDetails() {
		sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        List<String> doctorDetails = new ArrayList<String>();
        
        //Total doctors
        doctorDetails.add(showAllDoctors().size() + "");
        
        //Available doctors
        doctorDetails.add(session.createQuery("SELECT count(*) from Doctor where doctorStatus = 'AVAILABLE'").list().get(0) + "");
        
        //Assigned doctors
        doctorDetails.add(session.createQuery("SELECT count(*) from Doctor where doctorStatus = 'UNAVAILABLE'").list().get(0) + "");
        
        return doctorDetails;
	}
	
	//search Doctor
    public List<Doctor> searchDoctor(int doctorId) {        
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(Doctor.class);
        criteria.add(Restrictions.eq("doctorId", doctorId));
        List<Doctor> doctorlist = criteria.list();
        return doctorlist;
    }

    //Update Doctor
    public String updateDoctor(Doctor doctor) {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.update(doctor);
        transaction.commit();
        session.close();
        return "Patient Detals Updated Successfully.";
    }

	 
	//ADD Issue
    public String addIssue(Issues issues) {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.save(issues);
        transaction.commit();
        session.close();
        return "show-issues.xhtml?faces-redirect=true";
    }
    
    //Show Issues
    public List<Issues> showIssues() {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from Issues");
        List<Issues> issuesList = query.list();
        return issuesList;
    }
    
    //Issue Details
    public List[] issueDetails() {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        List<String[]> issueDetails =  (List<String[]>) (session.createSQLQuery("SELECT issues.issue, COUNT(*) AS count FROM treatmentdetails INNER JOIN issues ON treatmentdetails.issue_id = issues.issue_id GROUP BY issues.issue").list());
        
        List<String> labels = new ArrayList<>();
        List<Long> counts = new ArrayList<>();
        
        for (Object[] result : issueDetails) {
        	labels.add("'" + (String) result[0] + "'");
    		counts.add(((BigInteger) result[1]).longValue());
        }
        
        return new List[] {labels, counts};
	}
    
    //Get Room Limit
    public int roomLimit() {
		return (int) SessionHelper.getConnection().openSession().createSQLQuery("SELECT room__limit from room_limit LIMIT 1").list().get(0);
	}
    
    //Update Room Limit
    public void updateRoomLimit(int roomLimit) {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        RoomLimit newRoomLimit = new RoomLimit();
        newRoomLimit.setRoomLimit(roomLimit);
        newRoomLimit.setId(1);
        
        session.update(newRoomLimit);
        session.beginTransaction().commit();
        session.close();
	}
    
    
    //Add Room
    public void addRoom(double roomCost) {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        Room room = new Room();
        room.setRoomCost(roomCost);
        room.setStatus("AVAILABLE");
        
        session.save(room);
        session.beginTransaction().commit();
        session.close();
	}
    
    //Show Rooms
    @SuppressWarnings("unchecked")
	public List<Room> showRooms() {
    	sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        
        List<Room> roomList = session.createQuery("from Room").list();
        return roomList;
	}
    
    public List<Room> searchRoom(int roomId) {        
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(Room.class);
        criteria.add(Restrictions.eq("roomId", roomId));
        List<Room> roomlist = criteria.list();
        return roomlist;
    }

    //update Room 
    public String updateRoom(Room room) {
        sessionFactory = SessionHelper.getConnection();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.update(room);
        transaction.commit();

        return "room Updated succesfully.";
    }
    
    //Room Details
    public List<String> roomDetails() {
    	sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		
		List<String> roomDetails = new ArrayList<String>();
		
		//Total rooms
		roomDetails.add(showRooms().size() + "");
		
		//Available rooms
		roomDetails.add(showAvailableRooms().size() + "");
		
		//Unavailable rooms
		roomDetails.add((showRooms().size() - showAvailableRooms().size()) + "");
		
		return roomDetails;
	}
	
	
    //Validations
    public void validateName(FacesContext context, UIComponent comp, Object value) {
    	System.out.println("inside validate method");
    	String mno = (String) value;
        String pattern = "(?=.*[a-z])(?=.*[A-Z])(?=.*[/\\s]).{8,}";
        boolean result = mno.matches(pattern);
        
        if(result==false) {
        	((UIInput) comp).setValid(false);
            FacesMessage message = new FacesMessage("invalid Name");
            context.addMessage(comp.getClientId(context), message);
        }
    }
    
    public void validateAddress(FacesContext context, UIComponent comp, Object value) {
    	System.out.println("inside validate method");
        String mno = (String) value;
        String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[/\\s]).{8,}";
        boolean result=mno.matches(pattern);
        if(result==false) {
        	((UIInput) comp).setValid(false);
            FacesMessage message = new FacesMessage("invalid Address");
            context.addMessage(comp.getClientId(context), message);
         }
    }
    
    public void validateMobNo(FacesContext context, UIComponent comp,
	    Object value) {

	    System.out.println("inside validate method");

	    String mno = (String) value;
	    boolean flag = false;
	    if (mno.matches("\\d{10}")) {
	        flag = true;
	    }

	    if (flag == false) {
	        ((UIInput) comp).setValid(false);

	        FacesMessage message = new FacesMessage("Mobile Number is NOT valid, please enter a valid mobile number and try again.");
	        context.addMessage(comp.getClientId(context), message);
	    }
    }

	public void validateEmail(FacesContext context, UIComponent comp,
	    Object value) {

	    System.out.println("inside validate method");

	    String mno = (String) value;
	    if (mno.indexOf('@') == -1) {
	        ((UIInput) comp).setValid(false);

	        FacesMessage message = new FacesMessage(
	            "invalid Email Id");
	        context.addMessage(comp.getClientId(context), message);
	    }
	}

	public void validateDes(FacesContext context, UIComponent comp,
	    Object value) {

	    System.out.println("inside validate method");

	    String mno = (String) value;
	    String pattern = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\s]).{8,}";
	    boolean result = mno.matches(pattern);
	    if (result == false) {
	        ((UIInput) comp).setValid(false);

	        FacesMessage message = new FacesMessage(
	            "invalid Description");
	        context.addMessage(comp.getClientId(context), message);
	    }
	}
	public void validateSpe(FacesContext context, UIComponent comp,
	    Object value) {

	    System.out.println("inside validate method");

	    String mno = (String) value;
	    String pattern = "(?=.*[a-z])(?=.*[A-Z]).{3,}";
	    boolean result = mno.matches(pattern);
	    if (result == false) {
	        ((UIInput) comp).setValid(false);

	        FacesMessage message = new FacesMessage(
	            "invalid Specialization");
	        context.addMessage(comp.getClientId(context), message);
	    }
	}
	
	 public void validateUserName(FacesContext context, UIComponent comp, Object value) {
		 String mno = (String) value;
		 String pattern = "(?=.*[a-z])(?=.*[0-9]).{8,}";
		 boolean result = mno.matches(pattern);
	   
		 if (result == false) {
			 ((UIInput) comp).setValid(false);
			 FacesMessage message = new FacesMessage("invalid UserName");
			 context.addMessage(comp.getClientId(context), message);
	     }
	 }

	 public void validatePassword(FacesContext context, UIComponent comp, Object value) {
		 String mno = (String) value;
		 String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
		 boolean result = mno.matches(pattern);
		 
		 if (result == false) {
			 ((UIInput) comp).setValid(false);
	
			 FacesMessage message = new FacesMessage("Your password must have 8 characters long and have atleast one uppercase, lowercase, special character and number");
			 context.addMessage(comp.getClientId(context), message);
		 }
	 }
	 
	 public void validateIssue(FacesContext context, UIComponent comp, Object value) {
         String mno = (String) value;
         String pattern = "(?=.*[a-z])(?=.*[A-Z]).{3,}";
         boolean result = mno.matches(pattern);
         
         if(result==false) {
        	 ((UIInput) comp).setValid(false);
             FacesMessage message = new FacesMessage("Please enter a valid Issue Name, and try again.");
             context.addMessage(comp.getClientId(context), message);
         }
     }
	 
	 public void redirectToLogin() throws IOException {
		 FacesContext context = FacesContext.getCurrentInstance();
		 ExternalContext externalContext = context.getExternalContext();
		 externalContext.redirect("user-login.xhtml");
//		 return "user-login.xhtml?faces-redirect=true";
	 }
	 
	 public void redirectToIndex() throws IOException {
		 FacesContext context = FacesContext.getCurrentInstance();
		 ExternalContext externalContext = context.getExternalContext();
		 externalContext.redirect("index.jsp");
//		 return "user-login.xhtml?faces-redirect=true";
	 }
}
