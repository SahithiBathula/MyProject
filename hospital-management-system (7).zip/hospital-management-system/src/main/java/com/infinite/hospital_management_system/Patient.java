package com.infinite.hospital_management_system;

 

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 

@Entity
@Table(name="patientdetails")
@ManagedBean
@SessionScoped
public class Patient {
    @Id
    @Column(name="patient_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int patientId;

    @Column(name="patient_name")
    private String patientName;

    @Column(name="patient_phone")
    private String patientPhone;

    @Column(name="patient_state")
    private String patientState;

    @Column(name="patient_email")
    private String patientEmail;

    @Column(name="patient_aadhaar")
    private String patientAadhaar;

    @Column(name="patient_city")
    private String patientCity;

    @Column(name="patient_pincode")
    private String patientPincode;
    
    
    public String getPatientState() {
        return patientState;
    }
    public void setPatientState(String patientState) {
        this.patientState = patientState;
    }
    public int getPatientId() {
        return patientId;
    }
    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }
    public String getPatientName() {
        return patientName;
    }
    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    public String getPatientPhone() {
        return patientPhone;
    }
    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }
    public String getPatientEmail() {
        return patientEmail;
    }
    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }
    public String getPatientAadhaar() {
        return patientAadhaar;
    }
    public void setPatientAadhaar(String patientAadhaar) {
        this.patientAadhaar = patientAadhaar;
    }
    public String getPatientCity() {
        return patientCity;
    }
    public void setPatientCity(String patientCity) {
        this.patientCity = patientCity;
    }
    public String getPatientPincode() {
        return patientPincode;
    }
    public void setPatientPincode(String patientPincode) {
        this.patientPincode = patientPincode;
    }
}