package com.infinite.hospital_management_system;

public class Test {
	public static void main(String[] args) {
		
	}
}
